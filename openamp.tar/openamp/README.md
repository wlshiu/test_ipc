# test_rpc

# Reference
---
[LPCOpen-keil-lpc43xx](https://github.com/micromint/LPCOpen-keil-lpc43xx)
